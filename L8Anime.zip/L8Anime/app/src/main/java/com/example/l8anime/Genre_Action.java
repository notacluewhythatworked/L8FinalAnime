package com.example.l8anime;

import java.util.ArrayList;

public class Genre_Action {
    public ArrayList<String> titlesA = new ArrayList<String>();
    public Genre_Action(){
        titlesA.add("Ansatsu Kyoushitsu");
        titlesA.add("Dragon Ball Z");
        titlesA.add("FLCL (Fooly Cooly)");
        titlesA.add("Black Lagoon");
        titlesA.add("Deadman Wonderland");
        titlesA.add("Sword Art Online");
        titlesA.add("Accel World");
        titlesA.add("Shingeki no Kyojin");
        titlesA.add("Tokyo Ghoul");
        titlesA.add("Naruto");
    }
}
