package com.example.l8anime;

import java.util.ArrayList;

public class Genre_Scifi {
    public ArrayList<String> titlesSF = new ArrayList<String>();
    public Genre_Scifi(){
        titlesSF.add("Cowboy Bebop");
        titlesSF.add("Code Geass: Hangyaku no Lelouch");
        titlesSF.add("Neon Genesis Evangelion");
        titlesSF.add("Darling in the FranXX");
        titlesSF.add("Ghost in the Shell");
        titlesSF.add("Black Bullet");
        titlesSF.add("Tengen Toppa Gurren Lagann");
        titlesSF.add("Btooom!");
        titlesSF.add("Trigun");
        titlesSF.add("Infinite Stratos");
    }
}
