package com.example.l8anime;

import java.util.ArrayList;

public class Genre_Horror {
    public ArrayList<String> titlesH = new ArrayList<String>();
    public Genre_Horror(){
        titlesH.add("Higurashi");
        titlesH.add("Parasyte");
        titlesH.add("Another");
        titlesH.add("Yamishibai");
        titlesH.add("Boogiepop Phantom");
        titlesH.add("Shiki");
        titlesH.add("Paranoia Agent");
        titlesH.add("Blood+");
        titlesH.add("Ghost Hunt");
        titlesH.add("Death Note");
    }
}
