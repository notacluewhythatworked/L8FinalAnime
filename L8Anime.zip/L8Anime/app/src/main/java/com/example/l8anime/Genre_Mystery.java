package com.example.l8anime;

import java.util.ArrayList;

public class Genre_Mystery {
    public ArrayList<String> titlesMy = new ArrayList<String>();
    public Genre_Mystery(){
        titlesMy.add("The Promised Neverland");
        titlesMy.add("Bungo Stray Dogs");
        titlesMy.add("Durarara!!");
        titlesMy.add("Detective Conan");
        titlesMy.add("Made In Abyss");
        titlesMy.add("Mushishi");
        titlesMy.add("Baccano!");
        titlesMy.add("Beautiful Bones - Sakurako's Investigation");
        titlesMy.add("Un-Go");
        titlesMy.add("Higurashi no Naku Koro ni");
    }
}
