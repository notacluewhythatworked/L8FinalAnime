package com.example.l8anime;

import java.util.ArrayList;

public class Genre_SchoolLife {
    public ArrayList<String> titlesSL = new ArrayList<String>();
    public Genre_SchoolLife(){
        titlesSL.add("Chuunibyou demo Koi ga Shitai!");
        titlesSL.add("Rosario to Vampire");
        titlesSL.add("Kami nomi zo Shiru Sekai");
        titlesSL.add("Demi-chan wa Kataritai");
        titlesSL.add("Ben-to");
        titlesSL.add("Boku no Hero Academia");
        titlesSL.add("Shokugeki no Souma: Ni no Sara");
        titlesSL.add("Kakegurui");
        titlesSL.add("Absolute Duo");
        titlesSL.add("Karakai Jouzu no Takagi-san");
    }
}
