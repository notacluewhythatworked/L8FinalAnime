package com.example.l8anime;

import java.util.ArrayList;

public class Genre_Romance {
    public ArrayList<String> titlesR = new ArrayList<String>();
    public Genre_Romance(){
        titlesR.add("Toradora!");
        titlesR.add("sankarea");
        titlesR.add("My Little Monster");
        titlesR.add("Your Lie in April");
        titlesR.add("The Kawai Complex Guide to Manors and Hostel Behavior");
        titlesR.add("From Me to You");
        titlesR.add("Golden Times");
        titlesR.add("Blue Spring Ride");
        titlesR.add("The Pet Girl of Sakurasou");
        titlesR.add("My Love Story!!");
    }
}
