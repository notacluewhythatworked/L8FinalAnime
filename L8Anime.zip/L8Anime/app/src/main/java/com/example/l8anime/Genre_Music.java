package com.example.l8anime;

import java.util.ArrayList;

public class Genre_Music {
    public ArrayList<String> titlesMu = new ArrayList<String>();
    public Genre_Music(){
        titlesMu.add("K-On!");
        titlesMu.add("Shigatsu wa Kimi no Uso");
        titlesMu.add("Love Live! Sunshine!!");
        titlesMu.add("Zombieland Saga");
        titlesMu.add("SoniAni: Super Sonico The Animation");
        titlesMu.add("Show By Rock!! Mashumairesh!!");
        titlesMu.add("Hibike! Euphonium");
        titlesMu.add("The iDOLM@STER");
        titlesMu.add("Sakamichi no Apollon");
        titlesMu.add("Shelter");
    }
}
