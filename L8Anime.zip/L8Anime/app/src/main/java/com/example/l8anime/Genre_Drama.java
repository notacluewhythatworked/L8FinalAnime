package com.example.l8anime;

import java.util.ArrayList;

public class Genre_Drama {
    public ArrayList<String> titlesD = new ArrayList<String>();
    public Genre_Drama(){
        titlesD.add("A Silent Voice");
        titlesD.add("ERASED");
        titlesD.add("Anohana: The Flower We Saw That Day");
        titlesD.add("Grave Of The Fireflies");
        titlesD.add("Orange");
        titlesD.add("Fruits Basket");
        titlesD.add("March Comes In Like A Lion");
        titlesD.add("A Lull in the Sea");
        titlesD.add("Welcome To The NHK!");
        titlesD.add("Rorouni Kenshin: Trust & Betrayal");
    }
}
